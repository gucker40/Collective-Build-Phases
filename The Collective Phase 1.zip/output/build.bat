@echo off
title The Collective - Build
cd /d "%~dp0"

echo.
echo  ============================================================
echo   THE COLLECTIVE - Build
echo  ============================================================
echo.

REM ── Step 1: Python venv ────────────────────────────────────────────────────
echo [1/3] Setting up Python environment...

python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
  echo  ERROR: Python not found. Install Python 3.11+ from python.org
  pause & exit /b 1
)
for /f "tokens=*" %%v in ('python --version 2^>^&1') do echo        Using %%v

cd backend

if exist "venv" (
  echo        Removing old venv...
  rmdir /s /q venv
)

echo        Creating venv...
python -m venv venv
if %ERRORLEVEL% NEQ 0 ( echo  ERROR: venv creation failed. & pause & exit /b 1 )

echo        Installing packages (fastapi, uvicorn, httpx...)
venv\Scripts\pip install -r requirements.txt --quiet --no-warn-script-location
if %ERRORLEVEL% NEQ 0 ( echo  ERROR: pip install failed. & pause & exit /b 1 )

echo        Venv ready.
cd ..

REM ── Step 2: Frontend ───────────────────────────────────────────────────────
echo [2/3] Building frontend...
cd frontend

if not exist "node_modules" (
  echo        Running npm install...
  call npm install --legacy-peer-deps --silent
)

call npm run build:vite
if %ERRORLEVEL% NEQ 0 ( echo  ERROR: Frontend build failed. & pause & exit /b 1 )
echo        Frontend built.
cd ..

REM ── Step 3: Package ────────────────────────────────────────────────────────
echo [3/3] Packaging installer...
cd frontend
call npx electron-builder --win --config electron-builder.json
if %ERRORLEVEL% NEQ 0 ( echo  ERROR: electron-builder failed. & pause & exit /b 1 )
cd ..

echo.
echo  ============================================================
echo   DONE.
for %%f in ("dist-app\*.exe") do echo   Installer: %%~ff
echo  ============================================================
echo.
pause
