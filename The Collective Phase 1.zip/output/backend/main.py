"""main.py - FastAPI app for The Collective"""

import asyncio
import os
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware

from models import load_config, save_config, get_loaded_models, warmup_all, test_provider

APPDATA = Path(os.environ.get("APPDATA", os.path.expanduser("~"))) / "the-collective"
for d in [APPDATA, APPDATA/"vault", APPDATA/"memory", APPDATA/"history", APPDATA/"logs"]:
    d.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="The Collective Backend")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

from router    import router as logos_router
from artifacts import router as artifacts_router
from vault    import router as vault_router
from memory   import router as memory_router
from history  import router as history_router

app.include_router(logos_router,     prefix="/logos")
app.include_router(artifacts_router,  prefix="/artifacts")
app.include_router(vault_router,   prefix="/vault")
app.include_router(memory_router,  prefix="/memory")
app.include_router(history_router, prefix="/history")

@app.get("/")
async def root():
    return {"status": "online", "service": "The Collective"}

@app.get("/health")
async def health():
    return {"status": "ok"}

@app.get("/settings")
async def get_settings():
    return load_config()

@app.post("/settings")
async def post_settings(request: Request):
    body = await request.json()
    save_config(body)
    return {"saved": True}

@app.post("/test/{provider}")
async def test_connection(provider: str):
    cfg = load_config()
    result = await test_provider(provider, cfg)
    return result

@app.post("/preload")
async def preload():
    asyncio.create_task(warmup_all())
    return {"started": True}

@app.on_event("startup")
async def on_startup():
    # Warmup after 10s — gives the app time to fully boot before touching models
    async def delayed_warmup():
        await asyncio.sleep(10)
        await warmup_all()
    asyncio.create_task(delayed_warmup())

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=False, log_level="warning")
