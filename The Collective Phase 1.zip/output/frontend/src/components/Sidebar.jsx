import React, { useState, useEffect } from "react";

const API = "http://localhost:8000";

const NAV = [
  { id:"chat",      label:"Chat",
    icon:<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M2.5 4a1 1 0 011-1h13a1 1 0 011 1v9a1 1 0 01-1 1H11.5L8 17v-3H3.5a1 1 0 01-1-1V4z" stroke="currentColor" strokeWidth="1.4" fill="none"/></svg> },
  { id:"artifacts", label:"Projects",
    icon:<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect x="3" y="3" width="6.5" height="6.5" rx="1.2" stroke="currentColor" strokeWidth="1.4"/><rect x="10.5" y="3" width="6.5" height="6.5" rx="1.2" stroke="currentColor" strokeWidth="1.4"/><rect x="3" y="10.5" width="6.5" height="6.5" rx="1.2" stroke="currentColor" strokeWidth="1.4"/><path d="M13.75 10.5v6.5M10.5 13.75h6.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg> },
  { id:"vault",    label:"Vault",
    icon:<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><rect x="2.5" y="2.5" width="15" height="15" rx="2" stroke="currentColor" strokeWidth="1.4"/><path d="M6 7h8M6 10h8M6 13h5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg> },
  { id:"memory",   label:"Memory",
    icon:<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" strokeWidth="1.4"/><circle cx="10" cy="10" r="2.8" stroke="currentColor" strokeWidth="1.4"/><path d="M10 3v1.5M10 15.5V17M3 10h1.5M15.5 10H17" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg> },
  { id:"settings", label:"Settings",
    icon:<svg width="20" height="20" viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="2.8" stroke="currentColor" strokeWidth="1.4"/><path d="M10 2v2M10 16v2M2 10h2M16 10h2M4.22 4.22l1.42 1.42M14.36 14.36l1.42 1.42M4.22 15.78l1.42-1.42M14.36 5.64l1.42-1.42" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round"/></svg> },
];

export default function Sidebar({ activeView, onNavigate, onNewChat }) {
  const [status, setStatus] = useState({});
  useEffect(() => {
    const check = async () => {
      try { const r = await fetch(`${API}/logos/status`); const d = await r.json(); setStatus(d.council||{}); } catch {}
    };
    check();
    const t = setInterval(check, 20000);
    return () => clearInterval(t);
  }, []);

  return (
    <div style={{ width:"68px", flexShrink:0, background:"rgba(5,5,10,0.9)", borderRight:"1px solid rgba(160,122,255,0.15)", display:"flex", flexDirection:"column", alignItems:"center", padding:"14px 0 12px", gap:"3px" }}>
      {/* Sigil */}
      <div onClick={onNewChat} title="New chat" style={{ width:"46px", height:"46px", display:"flex", alignItems:"center", justifyContent:"center", marginBottom:"12px", cursor:"pointer" }}>
        <svg width="40" height="40" viewBox="0 0 40 40" fill="none" style={{ animation:"breathe 3.5s ease-in-out infinite" }}>
          <circle cx="20" cy="20" r="18.5" stroke="rgba(200,180,255,0.45)" strokeWidth="1"/>
          <circle cx="20" cy="20" r="14" stroke="rgba(160,122,255,0.25)" strokeWidth="0.6" strokeDasharray="2 4"/>
          <polygon points="20,6.5 31,25.5 9,25.5" fill="none" stroke="rgba(160,122,255,0.9)" strokeWidth="1.2"/>
          <polygon points="20,33.5 9,14.5 31,14.5" fill="none" stroke="rgba(160,122,255,0.55)" strokeWidth="0.9"/>
          <circle cx="20" cy="20" r="3" fill="rgba(240,192,64,1)"/>
        </svg>
      </div>

      <div style={{ width:"36px", height:"1px", background:"rgba(160,122,255,0.25)", margin:"2px 0 8px" }} />

      {NAV.map(({ id, label, icon }) => {
        const active = activeView === id;
        return (
          <button key={id} onClick={() => onNavigate(id)} title={label}
            style={{ width:"48px", height:"48px", borderRadius:"12px", display:"flex", alignItems:"center", justifyContent:"center", border: active ? "1px solid rgba(160,122,255,0.5)" : "1px solid transparent", background: active ? "rgba(160,122,255,0.22)" : "transparent", color: active ? "#c4a0ff" : "#7868a0", cursor:"pointer", transition:"all 0.15s", marginBottom:"3px" }}
            onMouseEnter={e => { if (!active) { e.currentTarget.style.background="rgba(160,122,255,0.14)"; e.currentTarget.style.color="#c4a0ff"; }}}
            onMouseLeave={e => { if (!active) { e.currentTarget.style.background="transparent"; e.currentTarget.style.color="#7868a0"; }}}
          >{icon}</button>
        );
      })}

      {/* Status */}
      <div style={{ marginTop:"auto", display:"flex", flexDirection:"column", alignItems:"center", gap:"5px" }}>
        {[["P","pneuma"],["T","techne"],["O","opsis"]].map(([lbl, key]) => (
          <div key={lbl} title={`${key}: ${status[key]?"ready":"not loaded"}`}
            style={{ width:"22px", height:"22px", borderRadius:"5px", display:"flex", alignItems:"center", justifyContent:"center", fontFamily:"'Cinzel',serif", fontSize:"9px", letterSpacing:"0.05em", color: status[key] ? "#f0c040" : "#443860", background: status[key] ? "rgba(240,192,64,0.1)" : "transparent", border: status[key] ? "1px solid rgba(240,192,64,0.25)" : "1px solid rgba(160,122,255,0.1)" }}
          >{lbl}</div>
        ))}
      </div>
    </div>
  );
}
