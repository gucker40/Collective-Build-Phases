import React, { useState, useCallback, useEffect } from "react";
import LoadingScreen from "./components/LoadingScreen.jsx";
import Sidebar from "./components/Sidebar.jsx";
import ChatPanel from "./components/ChatPanel.jsx";
import ArtifactPanel from "./components/ArtifactPanel.jsx";
import MemoryVault from "./components/MemoryVault.jsx";
import VaultEditor from "./components/VaultEditor.jsx";
import SettingsPanel from "./components/SettingsPanel.jsx";
import TitleBar from "./components/TitleBar.jsx";
import HistorySidebar from "./components/HistorySidebar.jsx";
import ArtifactHistory from "./components/ArtifactHistory.jsx";

export default function App() {
  const [ready, setReady]                 = useState(false);
  const [fadeIn, setFadeIn]               = useState(false);
  const [activeView, setActiveView]       = useState("chat");
  const [artifact, setArtifact]           = useState(null);
  const [artifactOpen, setArtifactOpen]   = useState(false);
  const [notification, setNotification]   = useState(null);
  const [activeSession, setActiveSession] = useState(null);
  const [historyRefresh, setHistoryRefresh] = useState(0);
  const [chatKey, setChatKey] = useState(0);

  function handleReady() {
    setReady(true);
    setTimeout(() => setFadeIn(true), 50);
  }

  const openArtifact  = useCallback((data) => {
    // During streaming: update content in place without remounting
    // Only do the null->set cycle when switching to a genuinely new artifact title
    setArtifact(prev => {
      if (prev && prev.title === data.title) {
        // Same artifact — just update content, no remount
        return { ...prev, content: data.content };
      }
      // New artifact — open fresh (but still avoid the null flash)
      return data;
    });
    setArtifactOpen(true);
  }, []);
  const closeArtifact = useCallback(() => { setArtifactOpen(false); setTimeout(() => setArtifact(null), 350); }, []);
  const notify        = useCallback((text, type = "success") => { setNotification({ text, type }); setTimeout(() => setNotification(null), 2800); }, []);
  const onSessionSaved = useCallback(() => setHistoryRefresh(n => n + 1), []);
  const handleLoadSession = useCallback((s) => { setActiveSession(s); setActiveView("chat"); }, []);
  const handleNewChat     = useCallback(() => { setActiveSession(null); setActiveView("chat"); setChatKey(k => k+1); }, []);

  const nc = ({ success: ["rgba(80,216,144,0.15)","rgba(80,216,144,0.4)","#50d890"], error: ["rgba(255,96,96,0.15)","rgba(255,96,96,0.4)","#ff9090"], info: ["rgba(240,192,64,0.15)","rgba(240,192,64,0.4)","#f0c040"] })[notification?.type || "info"];

  if (!ready) return <LoadingScreen onReady={handleReady} />;

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"100vh", width:"100vw", overflow:"hidden", background:"#0d0d1a", opacity: fadeIn ? 1 : 0, transition:"opacity 0.5s ease" }}>
      <TitleBar />
      {notification && (
        <div style={{ position:"absolute", top:"44px", left:"50%", transform:"translateX(-50%)", zIndex:50, padding:"8px 20px", borderRadius:"8px", background:nc[0], border:`1px solid ${nc[1]}`, color:nc[2], fontFamily:"'IBM Plex Mono',monospace", fontSize:"12px", whiteSpace:"nowrap" }}>
          {notification.text}
        </div>
      )}
      <div style={{ display:"flex", flex:1, overflow:"hidden" }}>
        <Sidebar activeView={activeView} onNavigate={setActiveView} onNewChat={handleNewChat} />
        <HistorySidebar refresh={historyRefresh} onLoad={handleLoadSession} onNew={handleNewChat} activeSessionId={activeSession?.id} />
        <div style={{ display:"flex", flex:1, overflow:"hidden" }}>
          <div style={{ display:"flex", flexDirection:"column", flex:1, overflow:"hidden" }}>
            {activeView === "chat"     && <ChatPanel key={chatKey} onArtifact={openArtifact} onNotify={notify} loadedSession={activeSession} onSessionSaved={onSessionSaved} />}
            {activeView === "artifacts" && <ArtifactHistory onOpen={openArtifact} />}
            {activeView === "vault"    && <VaultEditor onNotify={notify} />}
            {activeView === "memory"   && <MemoryVault onNotify={notify} />}
            {activeView === "settings" && <SettingsPanel />}
          </div>
          <ArtifactPanel artifact={artifact} open={artifactOpen} onClose={closeArtifact} onNotify={notify} />
        </div>
      </div>
    </div>
  );
}
