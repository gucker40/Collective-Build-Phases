const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("electronAPI", {
  minimize:         () => ipcRenderer.send("window-minimize"),
  maximize:         () => ipcRenderer.send("window-maximize"),
  close:            () => ipcRenderer.send("window-close"),
  getConfig:        () => ipcRenderer.invoke("get-config"),
  saveConfig:       (cfg) => ipcRenderer.invoke("save-config", cfg),
  getStatus:        () => ipcRenderer.invoke("get-status"),
  getPowerState:    () => ipcRenderer.invoke("get-power-state"),
  onPowerChanged:   (cb) => ipcRenderer.on("power-changed", (_, d) => cb(d)),
  openHtml:         (html, filename) => ipcRenderer.invoke("open-html", html, filename),
});
